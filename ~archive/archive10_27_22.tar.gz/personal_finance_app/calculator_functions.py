def calculate_return_beta(principal, avg_interest, years, avg_inflation = 0,cap_tax_rate = 0):
    raw_return = principal*(1 + avg_interest/100-avg_inflation/100)**years
    taxes = (raw_return-principal) * cap_tax_rate/100
    tax_adjusted_return = raw_return - taxes
    value_added = tax_adjusted_return - principal
    return list([round(tax_adjusted_return, 2), round(taxes, 2), round(value_added, 2)])


def calculate_return(principal, avg_interest, years):
    raw_return = principal*(1 + avg_interest)**years
    return round(raw_return,2)

#Calculate inflation adjusted return
def calculate_real_return(principal, avg_interest, avg_inflation, years):
    real_interest = avg_interest - avg_inflation
    real_return = principal * (1 + real_interest) ** years
    return round(real_return, 2)

#Calculate simple return, accounting for capital gains tax
def calculate_return_wtaxes(principal, avg_interest, avg_inflation, years, cap_tax_rate):
    raw_return = principal*(1+ avg_interest)**years
    taxes = (raw_return - principal) * cap_tax_rate
    tax_adjusted_return = raw_return - taxes
    return round(tax_adjusted_return, 2)

#Calculat real return, accounting for capital gains tax
def calculate_real_return_taxes(principal, avg_interest, avg_inflation, years, cap_tax_rate):
    real_interest = avg_interest - avg_inflation
    raw_return = principal*(1+avg_interest)** years
    real_return = principal*(1+real_interest)**years
    taxes = (raw_return - principal) * cap_tax_rate
    net_real_return = real_return - taxes
    return round(net_real_return, 2)

#Test these functions a few times 
print(calculate_return(100, 10, 1))
print(calculate_return_beta(100, 10, 1, 2, 10))
#print(calculate_real_return(100, 10, 1, 1))
#print(calculate_return_wtaxes(100, 10, 1, 1, 1))
#print(calculate_real_return_taxes(100, 10, 1, 1, 1))

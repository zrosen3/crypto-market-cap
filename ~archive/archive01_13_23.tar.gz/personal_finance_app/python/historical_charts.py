#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
The purpose of these charts is to show how various investment options compare over time. Including inflation, I will show
the value of a generic stock index, bond index, housing index, savings index, and cash over time. Individual investments
will vary more than these indices, but you can essentially buy these indices through exchange traded funds. 
"""


import pandas as pd
import numpy as np
import random
''' Create a table which shows value of 50,000 over time with various levels of inflation. This table is the same as 
Table 3.5: The corrosive impact of modest inflatino on fixed pensions from "Investment book" by XX and YY'''
#Set initial parameters
principal = 50000
inflation_nums = [0.01,0.02,0.03,0.04]
years = [10, 20, 30, 35]
value_list = list()

#add values to list
for inflation in inflation_nums:
    for year in years:
        value = principal/((1+inflation)**year)
        value_list.append(value)

#reshape and format table
array= np.array(value_list)
reshaped = array.reshape(4,4)
df = pd.DataFrame(reshaped, columns=['10 years', '20 years', '30 years', '35 years'])
df["Inflation"] = ["1%", "2%", "3%", "4%"]
df = df.set_index("Inflation")
df.index.name = ""
pd.options.display.float_format = '${:,.0f}'.format
print(df)


''' Instead of letting the money stay as cash, let's say that the money was invested instead. Assuming a real interest rate between 
6% and 12%, see the value of an initial investment over time below.'''
##Create a table which shows value of 50,000 over time with various levels of interest
principal2= 50000
interest_nums = [0.06, 0.08, 0.10, 0.12]
years2 = [10, 20, 30, 35]
value_list2 = list()
for real_interest in interest_nums:
    for year in years2:
        value = principal2*(1+real_interest)**year
        value_list2.append(value)
array2 = np.array(value_list2)
reshaped2 = array2.reshape(4,4)
df2 = pd.DataFrame(reshaped2, columns=['10 years', '20 years', '30 years', '35 years'])
df2["Inflation"] = ["1%", "2%", "3%", "4%"]
df2 = df2.set_index("Inflation")
df2.index.name = ""
pd.options.display.float_format = '${:,.0f}'.format
print(df2)

'''
Investment return from stocks does not tend to be steady over time. Let's assume we have varying yearly returns over a 30 year period, which average 
out to 8%. This model is meant to approximate the behavior of the S&P 500 over time, which has an average inflation adjusted
return of ~8%. Each time this model runs, the return is generated randomly from a number between -10 and 20. 
'''
principal3 = 50000
value = principal3
interest_nums =[random.uniform(-10, 20)/100 for i in range(0, 35)]
years3 = [0, 10, 20, 30, 25]
value_list3 = [value]
for year in range(0, 35):
        value = value  * (1 + interest_nums[year])
        print(value)
        value_list3.append(value)
rounded_values = [round(x, 2) for x in value_list3]
df3 = pd.DataFrame(rounded_values)
df3.index.name = "Year"
df3.columns = ["Value"]
print(df3.filter(items = [0,10, 20, 30, 35], axis=0))
#print(df3)

    
"""
This script defines functions to be used in a personal finance app web page. 
The application allows you to see returns from various potential investments.
"""
#import libraries, initialize app
from flask import Flask, render_template, request
from calculator_functions import calculate_return
app = Flask(__name__)
#load in interest functions from other file

#Displays the index page accessible at '/'
@app.route('/', methods = ['GET'])
def index():
    return render_template('index.html')

#Simple interest calculation
@app.route('/simple_interest/', methods = ['POST'])
def simple_interest():
    result = None
    #extract inputs from user submission
    principal_text = request.form['Principal1']
    interest_text = request.form['Interest1']
    years_text = request.form['Years1']
    principal = float(principal_text)
    interest = float(interest_text)
    years = float(years_text)
    try:
        result = calculate_return(principal, interest, years)
    #return value
        return(
        render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest *100,
                         Years1 = years,
                         result1 = result,
                         calculation_success = True
                         ))
    #return error messages if exceptions
    except ValueError:
         return (render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest_text,
                         Years1 = years,
                         result1 = result,
                         calculation_success = False,
                         error = "Cannot peform operations with provided input"
                         ))
#Simple interest calculation, including tax
@app.route('/simple_interest_taxed/', methods = ['POST'])
def simple_interest_taxed():
    result = None
    #extract inputs from user submission
    principal_text = request.form['Principal2']
    interest_text = request.form['Interest2']
    tax_text = request.form['Tax2']
    years_text = request.form['Years2']
    principal = float(principal_text)
    interest = float(interest_text)
    tax = float(tax_test)
    years = float(years_text)
    try:
        result = calculate_return_wtaxes(principal, interest, years)
    #return value
        return(
        render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest,
                         Years1 = years,
                         result1 = result,
                         calculation_success = True
                         ))
    #return error messages if exceptions
    except ValueError:
         return (render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest_text,
                         Years1 = years,
                         result1 = result,
                         calculation_success = False,
                         error = "Cannot peform operations with provided input"
                         ))
#Real interest calculation
@app.route('/simple_interest_taxed/', methods = ['POST'])
def real_interest():
    result = None
    #extract inputs from user submission
    principal_text = request.form['Principal1']
    interest_text = request.form['Interest1']
    years_text = request.form['Years1']
    principal = float(principal_text)
    interest = float(interest_text)
    years = float(years_text)
    try:
        result = calculate_return(principal, interest, years)
    #return value
        return(
        render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest,
                         Years1 = years,
                         result1 = result,
                         calculation_success = True
                         ))
    #return error messages if exceptions
    except ValueError:
         return (render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest_text,
                         Years1 = years,
                         result1 = result,
                         calculation_success = False,
                         error = "Cannot peform operations with provided input"
                         ))
#Real interest taxed
@app.route('/real_interest_taxed', methods = ['POST'])
def real_interest_taxed():
    result = None
    #extract inputs from user submission
    principal_text = request.form['Principal1']
    interest_text = request.form['Interest1']
    years_text = request.form['Years1']
    principal = float(principal_text)
    interest = float(interest_text)
    years = float(years_text)
    try:
        result = calculate_return(principal, interest, years)
    #return value
        return(
        render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest,
                         Years1 = years,
                         result1 = result,
                         calculation_success = True
                         ))
    #return error messages if exceptions
    except ValueError:
         return (render_template('index.html',
                         Principal1 = principal,
                         Interest1 = interest_text,
                         Years1 = years,
                         result1 = result,
                         calculation_success = False,
                         error = "Cannot peform operations with provided input"
                         ))




#Real interest calculation, including tax

if __name__ == '__main__':
    app.debug = True
    app.run()
